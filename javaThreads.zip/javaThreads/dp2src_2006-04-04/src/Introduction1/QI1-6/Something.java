public class Something {
    public                     void iA() { }
    public                     void iB() { }
    public        synchronized void iSyncA() { }
    public        synchronized void iSyncB() { }
    public static              void cA() { }
    public static              void cB() { }
    public static synchronized void cSyncA() { }
    public static synchronized void cSyncB() { }
}
