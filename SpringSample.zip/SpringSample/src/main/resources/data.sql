INSERT INTO employee (employee_id, employee_name, age)
VALUES(1, '山田太郎', 30);

