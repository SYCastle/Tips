import com.snowflake.snowpark._
import com.snowflake.snowpark.functions._
import TheJar.stringUdf

object Main {
  def main(args: Array[String]): Unit = {
    // Replace the <placeholders> below.
    val configs = Map(
      "URL" -> "https://ja16040.ap-northeast-1.aws.snowflakecomputing.com:443",
      "USER" -> "ysawada451",
      "PASSWORD" -> "48694062-Sh",
      "ROLE" -> "ACCOUNTADMIN",
      "WAREHOUSE" -> "GATCHAN",
      "DB" -> "PENGUIN",
      "SCHEMA" -> "PUBLIC"
    )
    val session = Session.builder.configs(configs).create
    //session.sql("show tables").show()

    //session.file.put("file://c:/tmp/getting-started/employees05.csv" , "@norimaki")
    session.sql("ls @norimaki").show()
    try {
      session.file.put(
        "./thejar/target/scala-2.12/thejar-assembly-0.1.0-SNAPSHOT.jar",
        "@norimaki",
        Map("AUTO_COMPRESS" -> "FALSE"))
      session.file.put("./thejar/target/scala-2.12/thejar-assembly-0.1.0-SNAPSHOT.jar", "@norimaki")
      session.addDependency("@norimaki/thejar-assembly-0.1.0-SNAPSHOT.jar")
      session.udf.registerTemporary("stringUdf", stringUdf(_))
      df.withColumn("upper_first_name", callUDF("stringUdf", col("first_name")))
        .show()
    } catch {
      case e: Exception => println(e.toString)
    } finally {
      session.close
    }
  }
}