object TheJar extends Serializable {

  lazy val prefix = {
    val resourceName = "/hello.txt"
    val inputStream = classOf[com.snowflake.snowpark.DataFrame]
      .getResourceAsStream(resourceName)
    if (inputStream == null) {
      throw new Exception("Can't find file " + resourceName)
    }
    scala.io.Source.fromInputStream(inputStream).mkString
  }

  def stringUdf(str: String): String = {
    prefix + str.toUpperCase
  }
}